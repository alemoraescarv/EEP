
import sys
sys.path.insert(0, '..')

from elapsed_time import *


#test function 
def solution(arr):
        maximum = 0
        
        for elem in arr:
            if elem > maximum:
                maximum = elem
        return maximum
if __name__=='__main__':
    r = measure_elapsed_time(solution, [1,2,3])
    print(r)
    