from input_code import solution
from elapsed_time import measure_elapsed_time

def get_test_cases():
    return {
        "SMALL_INPUT": [1, 2, 3],
        "LARGE_INPUT": [1, 2, 3] * 1000 + [4],
    }

def get_expected_outputs():
    return {
        "SMALL_INPUT": 3,
        "LARGE_INPUT": 4,
    }

def test_code():
    test_cases = get_test_cases()
    expected = get_expected_outputs()
    test_cases_count = len(test_cases)
    passed_test_cases = 0
    failed_test_cases = []
    solution_time = None

    for label in test_cases.keys():
        code_result = solution(test_cases[label])
        if code_result == expected[label]:
            passed_test_cases += 1
            solution_time = measure_elapsed_time(solution, test_cases[label])
        else:
            failed_test_cases.append(label)
    #is_fast_enough = a if True else b
    print("Passed", passed_test_cases, "out of", test_cases_count, "test cases.", solution_time, "seconds to run")
    
    #time for perfect solution - max points
    


    if len(failed_test_cases) > 0:
        print("Test cases not passed:", ", ".join(failed_test_cases))


test_code()